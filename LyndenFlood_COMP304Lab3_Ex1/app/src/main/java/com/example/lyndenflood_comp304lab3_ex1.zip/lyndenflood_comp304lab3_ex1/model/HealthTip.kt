
package com.example.lyndenflood_comp304lab3_ex1.model

data class HealthTip(
    val name: String,
    val type: String,
    val muscle: String,
    val difficulty: String,
    val instructions: String
)
